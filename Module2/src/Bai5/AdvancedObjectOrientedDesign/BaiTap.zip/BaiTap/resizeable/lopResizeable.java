package Bai5.AdvancedObjectOrientedDesign.BaiTap.resizeable;

public interface lopResizeable {
    void resize(double percent);
}
